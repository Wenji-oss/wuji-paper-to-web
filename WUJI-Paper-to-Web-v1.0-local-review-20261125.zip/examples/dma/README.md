# DMA project reference

mark-color.svg and mark-white.svg are project-specific marks copied from the approved local DMA v2. They are not the WUJI wordmark.
DMA online reference URL: not yet supplied. Do not fabricate a URL or copy private research videos into the generic template.
Historical deltas: v2 had #288BFF for some interactions; new tokens normalize to#207FFF. Latest approved Hero gap80px desktop/52px mobile retained. Original v2 HTML/CSS were not edited by creating this package.

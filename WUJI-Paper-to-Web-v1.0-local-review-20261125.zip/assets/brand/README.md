# WUJI identity
Source: user-specified “01- Wuji effect images/WUJI Logo.png”.
File: wuji-wordmark-white.png, transparent,1876×536. User confirmed public use of the logo is permitted; this package itself remains internal.
Use on dark background unchanged. On light background CSS filter:brightness(0) gives a black rendering without modifying the asset. Keep width:auto/height:auto ratio. No official vector source or min-size/clearspace manual supplied. Do not present a traced or raster-wrapped SVG as an official vector.
DMA project marks are examples/dma/ only.

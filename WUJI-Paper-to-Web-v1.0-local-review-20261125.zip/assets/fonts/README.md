# Font assets

Algorytm Mono files copied unchanged from the user's local `Algorytm Mono TRIAL` folder with permission. Exact filename prefix: AlgorytmMonoTRIAL. Included weights200/300/400/500/600/700. CSS alias: WUJI Algorytm Mono. Format: OTF, served with format('opentype'). Do not disguise these copies as formal font files.

User intends Algorytm to be the formal display face. The available files are marked TRIAL; a separate formal download bundle was not found. This local review deliberately retains that status. When formal files arrive, place them in algorytm/, update tokens/fonts.css URLs and exact weight mappings, check glyph coverage and record provenance. Prefer WOFF2 when supplied; do not claim conversion or a license grant that has not happened.

Geist / Geist Mono copied from DMA v2, with the supplied OFL.txt retained. tokens/fonts.css references bundled resources, no remote font requests and no local() dependency. Chinese text may use system CJK fallback; test the intended production language.

# Local validation — 2026-11-25

Status: PASS (local Chromium review, not production approval).

- Bundled Algorytm Mono and Geist loaded from files, no local() dependency.
- Starter checked at1920,1440,1280,768,390,320 CSS px; no page-wide horizontal overflow.
- Reading widths720px on desktop/tablet,350px at390,280px at320.
- Hero actions/video gap80px at≥768,52px below768.
- Task mode switches; simulated step progress, click selection and pause work.
- Temporary existing local22-second video tested without adding it to package: metadata loaded, click seek reached1 second, no controls, muted/loop true, progress followed currentTime.
- Count animation reached34/120/40.1 once; reduced-motion immediate values checked.
- Method click-pin/Escape checked.
-10 category/subset/metric combinations checked against explicitly synthetic config.
- Unreported data remains “—”; no substitute zeros.
- Selected blue rgb(32,127,255), hover white, keyboard selection checked.
- Reference viewport selector resizes real iframe;320/390 reference layout checked.
- No page JavaScript errors in exercised interactions.
- Reference and Results screenshots visually inspected; included as local visual baselines.
- HTML/CSS local dependency check and ZIP/hash integrity checked during packaging.

Not verified: Safari/Edge/actual mobile hardware; all production videos; real-paper data; formal non-TRIAL font package; online hosting, authentication or account permissions. No GitHub repository or preview website created.

Recheck local files: `python3 checks/check_package.py` from package root. Manifest validation will intentionally fail after edits until an updated manifest is generated.

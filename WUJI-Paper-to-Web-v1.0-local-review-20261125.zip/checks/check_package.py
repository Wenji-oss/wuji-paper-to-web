# -*- coding: utf-8 -*-
"""Local, read-only validation. Run: python3 checks/check_package.py"""
from pathlib import Path
import re,json,hashlib
from urllib.parse import unquote,urlsplit
root=Path(__file__).resolve().parents[1]
errors=[]
for f in root.rglob('*'):
    if f.suffix not in ('.html','.css'):continue
    text=f.read_text(encoding='utf-8')
    refs=re.findall(r'(?:src|href)=["\x27]([^"\x27]+)',text) if f.suffix=='.html' else re.findall(r'url\(["\x27]?([^\)"\x27]+)',text)
    for ref in refs:
        if ref.startswith(('#','data:','http:','https:','mailto:')):continue
        path=unquote(urlsplit(ref).path)
        if path and not (f.parent/path).exists():errors.append(f'{f.relative_to(root)} -> {ref}')
manifest=root/'MANIFEST.json'
if manifest.exists():
    for row in json.loads(manifest.read_text()):
        f=root/row['path']
        if not f.exists() or hashlib.sha256(f.read_bytes()).hexdigest()!=row['sha256']:errors.append('Hash mismatch: '+row['path'])
if errors:raise SystemExit('\n'.join(errors))
print('PASS: local HTML/CSS dependencies and manifest hashes')

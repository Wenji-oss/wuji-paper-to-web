# Changelog
## 1.0.0-local-review — 2026-11-25
- Derived from approved DMA v2; original files unchanged.
- Unified new-template interaction blue to #207FFF.
- Preserved hero actions/video spacing80px desktop and52px mobile.
- Added DESIGN.md, tokens, component contracts, icons and anatomy SVGs.
- Included WUJI white PNG and identified Algorytm Mono TRIAL files explicitly.
- Added local reference/starter, synthetic interactive data and production boundaries.
- Local review only; repository permissions and preview protection deferred.

### Attribution update
- Added Developer: Wenji Li to DESIGN.md, README.md and the visual reference page.

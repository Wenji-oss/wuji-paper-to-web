# WUJI Paper-to-Web · Local Review 1.0

**Developer: Wenji Li**

内部使用设计规范包。尚未创建 GitHub 仓库或在线访问保护。

## 从哪里开始

- [DESIGN.md](DESIGN.md)：人和 AI 的核心设计规范。
- [reference/index.html](reference/index.html)：可视化规范、色板、图标、SVG画框、响应式白模。
- [starter/index.html](starter/index.html)：可复制的新论文网页骨架。
- [docs/content-workflow.md](docs/content-workflow.md)：论文转网页协作流程。
- [docs/paper-input-template.md](docs/paper-input-template.md)：Researcher填写清单。
- [docs/acceptance.md](docs/acceptance.md)：验收标准。
- [ASSETS.json](ASSETS.json)：资产来源、状态与使用范围。

完整解压，双击 reference/index.html。也可在包根目录运行：

```sh
python3 -m http.server 8000
```

访问 http://localhost:8000/reference/ 。停止服务按 Ctrl+C。

此服务仅用于本地预览，不代表已设置密码。不要将它当作生产访问保护。

## 开发方式

复制整个包；编辑 starter/paper-config.js 和 starter/index.html，保留 tokens/、assets/、starter/ 的相对路径。详情见 docs/deployment.md。不要只拿一个HTML而丢弃CSS/JS/字体。

## 当前资产状态

WUJI Logo 为用户提供的透明PNG，非SVG；字体原文件带 TRIAL，保留标注并提供替换位置。图标为本包新建通用SVG，后续可单独迭代。没有真实演示视频，未填入尚未提供的DMA线上链接；所有示例数据明确标注。

当前新系统统一交互蓝为 #207FFF，未改动原 DMA v2。

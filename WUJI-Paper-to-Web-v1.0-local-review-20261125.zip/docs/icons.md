# UI icon system v1

assets/icons/ contains12 independentSVGs and sprite.svg. viewBox0 0 24 24,stroke1.5,currentColor. Nominal rendering16/20/24px. Rounded line caps are icon geometry, not the4px frame corner rule. This is a new consistent set for review; it can evolve without replacing components.

| Name | Semantic use |
|---|---|
| external-link | Opens a resource in another page |
| download | Actual downloadable resource only |
| copy | Clipboard action |
| chevron-right / chevron-left | Next / previous item |
| chevrons-right | Advance sequence |
| arrow-up | Back to top |
| menu / close | Toggle navigation/dialog |
| play / pause | Manual media fallback |
| check | Successful completion |

Inline SVG inherits currentColor through button states. External <img> does not inherit host text color into its SVG; use inlineSVG or an SVG sprite if recoloring is required. Do not rasterize buttons. A complete button is text+icon+HTML interaction surface, not one staticSVG.

Brand PNG is assets/brand/wuji-wordmark-white.png; do not confuse it with icons. DMA logos are project-specific examples, not generic WUJI brand marks.

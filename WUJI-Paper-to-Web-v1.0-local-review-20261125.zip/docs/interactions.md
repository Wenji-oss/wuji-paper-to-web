# Interaction specification

| State | Meaning | Example |
|---|---|---|
| default | Available, not selected | dark panel / secondary text |
| hover | Pointer only, no data change | Results white background black text |
| selected | Persistent active mode | #207FFF background black text |
| pressed | Action acknowledgement | contrast flip450ms; no persistent selection |
| focus-visible | Keyboard location | 2px action-blue outline |
| disabled | Not actionable | native disabled / explanatory unavailable label |
| loading | Waiting for material | stable placeholder, no fictional progress |
| error | Failed source | readable error and retry or alternate link |

Group selectors keep one selected item; maintain aria-pressed. ArrowLeft/Right, Home/End can move selection in button groups; native Enter/Space activate. Hover must never overwrite content selection.

## Video
Overview controls stay native. Supporting videos muted/playsinline/loop; observe viewport, pause hidden/offscreen; catch rejected play() promises. Reduced-motion uses a manual “Play clip” fallback. No mandatory overlay icon. Actual step progress = clamp((currentTime-start)/(nextStart-start),0,1). Last end is video.duration. Validate times when metadata loads. Never use a timer to approximate real video progress.

White model explicitly offers “Preview timing” for simulated steps. When a real src exists this control is replaced by actual video synchronization. It is an instructional simulation, not evidence.

## Chart
Changing category resets unavailable subset/metric choices. Unit, direction of better performance, protocol and data rows change together. Selection must never retain values belonging to the previous mode. Preserve top inset; bar values enter from the same top anchor as a line chart block. Unreported values display “—”. If interactive line data is added, offer keyboard equivalent to hover readout.

## Motion
Use requestAnimationFrame for time-dependent displays; cancel when hidden. One-shot count animations run once per page load and immediately finish with reduced motion. Menu hides downward and reappears upward, while keyboard focus keeps it visible. Respect user's manual pause on overview.

# Component contracts

SVG anatomy图在 components/anatomy/，只说明区域结构，不是生产UI截图，也不能替代HTML交互。

| Component | Required input | Geometry | Behavior / edge cases |
|---|---|---|---|
| media-single | src,poster,alt/caption,ratio,type | Outer4px; explicit media ratio; contain unless crop approved | Loading→ready/error; hero native controls; missing media placeholder |
| media-comparison | left/right inputs,labels | Paired ratio and aligned captions | Independent/synchronized playback must be specified, not assumed |
| video-steps | video + ordered step labels/startSeconds | rail4px; min56px;12/20px; left16px | Actual currentTime; seek; loop reset; invalid timestamp disabled |
| sequence-grid | Four sequences, titles, times | Two columns desktop;14px title;32px row gap | Each video's state scoped locally; switches at configured time boundaries |
| dataset | source/reference,transform labels,stats | #F4F4F4 media; side-by-side; readable counts | Counts once on entry; reduced motion final values; no invented data |
| method | nodes,edges,details | Outer#E7E7E7/inner#F4F4F4;4px | Hover/focus details; click pin;Escape clear; contained horizontal scroll |
| results | categories/subsets/metrics/rows/units/protocol | 3 layers; chart top32px;490px viewport; natural toolbar | Sync chart+description+unit; missing is not0; subset above metric |
| citation | approved BibTeX string | #353535; white Regular400 | Copy only on user action; select-text fallback |

Buttons use real <button type="button">. Decorative SVGs aria-hidden=true. Icon-only controls need aria-label. Stable title rows should reserve enough space for supported content; avoid clipping long future labels just to preserve a screenshot.

Sequence-grid and complex method/chart styles are specified here and illustrated in SVG. The starter intentionally demonstrates simpler equivalents; implement these extensions when a paper needs them. Do not claim the white model contains all production behaviors.

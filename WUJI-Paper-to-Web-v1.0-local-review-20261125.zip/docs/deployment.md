# Local review and later deployment

## Current phase
No remote repository or hosted preview. Open reference/index.html after full extraction. Local server from package root: `python3 -m http.server 8000`; visit /reference/ or /starter/. A local server is not authentication.

## Files needed for a future website
Copy starter/ contents to a deploy directory, plus tokens/ and assets/ as sibling directories at the same relative paths, OR adjust all linked paths consistently. Safest: deploy package subset with /starter/ as page URL. If using /index.html at root, change ../tokens/ and ../assets/ references in starter HTML to tokens/ and assets/; tokens/fonts.css must still resolve ../assets/fonts/. Include actual media/ referenced by the config. Test subdirectory deployment, not only root.

Do not deploy internal docs, ASSETS.json, checks or reference unless explicitly intended. Scientific materials and fonts are not automatically authorized for public distribution merely because the logo can be public.

## Server requirements
HTTPS; correct MIME types(text/html,text/css,text/javascript,image/svg+xml,image/png,font/otf,font/ttf,video/mp4). Video hosting should allow byte Range/206 and intended max file size. Keep media external, not base64 inHTML. CDN assets must be accessible to the intended audience; when fetch-based processing is used, configure CORS accordingly.

## Access later
Private Git repository and protected preview site are separate access surfaces. Use explicit account allowlists or platform-side authentication. Do not store a shared password in HTML/JS or imply that a front-end overlay protects downloaded files. User review precedes choosing/configuring these controls.

## Must replace before release
TRIAL font if formal package is required, synthetic data, empty URLs, placeholder media, illustration-only controls. Obtain paper approval and complete acceptance.md. Add version record and known limitations. No publish automation is included.

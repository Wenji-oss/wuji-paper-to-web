# Acceptance checklist

## Content
- [ ] Researcher approved authors/title/citation/claims/data/units/uncertainty.
- [ ] No DEMO ONLY, synthetic numbers, blank resource links or placeholder material in production.
- [ ] Every mode maps to correct media and text; every result tuple maps to correct data.
- [ ] Missing results displayed as unreported, never fabricated0.

## Visual
- [ ] Font files load without relying on local installation; weight names correct.
- [ ] WUJI PNG ratio preserved; DMA marks not used as WUJI identity.
- [ ] Interaction blue unified#207FFF; alpha applied to paint, not whole panel.
- [ ] Outer4px corners; header/media/footer joints remain square inside.
- [ ] Hero button/video gap80px desktop,52px mobile.
- [ ] Chart blocks align to32px top/24px small; toolbar stacks subset→metric.
- [ ] Step labels12px,16px left inset,consistent rows; no rapid blink progress.

## Behavior
- [ ] Steps seek actual video times; metadata validates bounds; loop resets.
- [ ] Only overview has native controls by default; fallback supports autoplay failure/reduced-motion.
- [ ] Hover/selected/focus/disabled distinguishable, keyboard works.
- [ ] Results metric units/protocol/rows update together, missing data handled.
- [ ] Copy citation works or selects text for manual copy.
- [ ] Offscreen/hidden media pause; count animation once; reduced motion checked.

## Layout/deployment
- [ ]1920,1440,1280,768,390 and320px: no whole-page horizontal overflow.
- [ ] Wider maps scroll within component; touch controls usable; long text tested.
- [ ] Chrome/Safari/Edge plus actual target mobile browsers checked (automated Chromium alone is insufficient).
- [ ] No404 or script errors; Range video seeking; real links; correct MIME.
- [ ] Access scope configured server-side before sharing protected preview.

Local package validation results are recorded in checks/REPORT.md; they are not production approval.

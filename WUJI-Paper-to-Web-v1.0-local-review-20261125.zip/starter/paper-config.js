/* EXAMPLE ONLY. Replace from Researcher-approved input. Never use these numbers as research evidence. */
window.PAPER={
 title:'Paper Title: A Clear Statement of the Research Contribution',
 authors:'Author One · Author Two · WUJI',
 abstract:'Introduce the problem, proposed method and evidence in a concise paragraph. Replace this text with approved paper content.',
 links:{paper:'',code:''},
 overview:{src:'',poster:''},
 citation:'@unpublished{example2026,\n  title = {Replace with approved title},\n  author = {Author One and Author Two},\n  year = {2026}\n}',
 tasks:[{name:'Task A',description:'Demonstrate a single capability with clear conditions.',src:'',poster:'',steps:[{label:'1 Grasp',time:0},{label:'2 Adjust',time:3},{label:'3 Turn',time:6},{label:'4 Place',time:9}]},{name:'Task B',description:'Explain how the action changes in a second setting.',src:'',poster:'',steps:[{label:'1 Approach',time:0},{label:'2 Align',time:4},{label:'3 Release',time:8}]}],
 results:[
  {name:'Simulation',title:'Comparison with baselines',description:'DEMO ONLY. These illustrative values show how controls map to data, not a research result.',subsets:[
   {name:'Unseen objects',metrics:[{name:'Success rate',unit:'%',max:100,values:[72,48,31]},{name:'Object tracking',unit:'mm',max:20,values:[4,9,14]},{name:'Hand tracking',unit:'°',max:12,values:[3,6,9]}]},
   {name:'Seen objects',metrics:[{name:'Success rate',unit:'%',max:100,values:[80,60,43]},{name:'Object tracking',unit:'mm',max:20,values:[3,7,11]},{name:'Hand tracking',unit:'°',max:12,values:[2,5,7]}]}]},
  {name:'Real world',title:'Evaluation beyond simulation',description:'DEMO ONLY. Supply trials, protocol, hardware and real-world conditions.',subsets:[{name:'Task set',metrics:[{name:'Success rate',unit:'%',max:100,values:[64,41,null]}]}]},
  {name:'Ablations',title:'Contribution of components',description:'DEMO ONLY. Replace rows with the evaluated variants and explain what was removed.',subsets:[{name:'Evaluation set',metrics:[{name:'Success rate',unit:'%',max:100,values:[72,58,43]}]}]},
  {name:'Training analysis',title:'Efficiency and resources',description:'DEMO ONLY. Link each measured value to hardware, data and evaluation setup.',subsets:[{name:'Shared setup',metrics:[{name:'Training time',unit:'h',max:12,values:[4.7,7.4,9.6]},{name:'Success rate',unit:'%',max:100,values:[77,74,71]}]}]}
 ],
 methods:['Proposed','Baseline A','Baseline B']
};

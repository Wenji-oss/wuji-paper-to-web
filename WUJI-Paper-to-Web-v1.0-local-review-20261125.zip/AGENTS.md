# Instructions for agents working in this package
Read DESIGN.md first, then docs/content-workflow.md and docs/components.md.
Use tokens/tokens.css as the numerical source. Keep reference and starter aligned.
Do not publish, create repositories, change access, or upload assets without an explicit user request.
Do not infer scientific data. Synthetic values are labeled DEMO ONLY; replace from approved paper input.
Placeholder controls require production material/data/timestamp mapping. Never claim production readiness from a white-model check.
Keep Algorytm TRIAL filenames/status truthful; do not rename them as a formal licensed font.
Use the supplied WUJI brand file, not examples/dma marks, for a WUJI page.
Preserve accessible keyboard behavior and visible focus when changing components.

# Internal use
Prepared for WUJI and explicitly authorized collaborators. Do not distribute the complete package outside that audience without authorization. This usage notice is not an access-control mechanism.
Third-party font terms remain in their respective asset directories; no blanket open-source license is asserted for brand, fonts or scientific materials.
No repository, upload, public preview, password or account system was created. GitHub access and preview protection are a later, separately approved phase.
